"""6V6 の球ごとのパラメータ探索（2026-10-31）
実機モデル（Volume 5）の 6V6 を、このファイルと同じフォルダの 6V6_param.lib の 6V6P に差し替え、
パラメータの組ごとに LTspice を実行して、実測（measurement_data/tube_*/）と同じ指標を計算する。

先に 6V6_param.lib の係数（.param c_... の空欄）を、公開版の 6V6.inc から写して入れておく（README の手順）。
空欄が残っていると、LTspice を動かす前にエラーで止まる。

パラメータの書き方（6V6_param.lib の 6V6P と同じ名前）:
  vofs_pct・ex_pct・mu2_pct・s0_pct : 元の値に対する変化（%）。0 で元の値
  kp・kn                              : 元の式に掛ける倍率。1 で元の式
  s1・sw・i0                          : 追加した項の値（s1 = 0 で追加項なし）
  指定しなかったものは既定値（元のモデル）のまま

配布版（Note 記事 #5 用、2026-10-31）で変えたのは次の点だけ（探索・指標の計算は元のまま）:
  - .cir・6V6_param.lib・tubes.lib・TANGO_M757.lib は、このファイルと同じフォルダから読む
  - LTspice の場所は環境変数 LTSPICE で変えられる（無ければ Windows の標準のインストール先）
  - コマンドラインで実行したときの記録は、同じフォルダの fit_6v6_log_new.jsonl に追記する
    （配布した探索の記録 fit_6v6_log_percent_20261031.jsonl には書き足さない）
  - パラメータを % で渡す形にした（6V6_param.lib に合わせて）。.cir に書く桁を増やした（%.10g）
  - 6V6_param.lib の係数が空欄のままなら止める

使い方（コマンドライン）:
    python fit_6v6.py <stage 名> <パラメータの組の JSON（リスト）> <作業フォルダ>
    例: python fit_6v6.py test "[{}, {\"mu2_pct\": -3.12, \"ex_pct\": 10.12}]" work
使い方（ほかのスクリプトから import して使う）:
    from fit_6v6 import run_sets, score
    res = run_sets([{'mu2_pct': -3.12, 'ex_pct': 10.12}, ...], work_dir)
"""
import os, re, subprocess, itertools, concurrent.futures as cf
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))       # 配布版: すべてこのフォルダ基準
TEMPLATE = os.path.join(HERE, '5F1_Actual_TRAN_Vol5Levels_20261031.cir')
PARAM_LIB = os.path.join(HERE, '6V6_param.lib')
LOCAL_LIBS = ['tubes.lib', 'TANGO_M757.lib']            # 作業フォルダの .cir から読めるよう、絶対パスに書き換えるライブラリ
LOG_PATH = os.path.join(HERE, 'fit_6v6_log_new.jsonl')
LTSPICE = os.environ.get('LTSPICE', r'C:\Program Files\ADI\LTspice\LTspice.exe')
LEVELS = [0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4]   # 入力（V peak）。実測と同じ（0.4 は最大出力）
OUT_PEAKS = [3.0, 5.0, 7.0]                       # THD をそろえる出力（V peak）
PARALLEL = 2                                      # 同時に動かす LTspice の数（6 だとスレッドの取り合いで極端に遅くなった）
TIMEOUT_S = 400

# 実測（measurement_data/tube_*/measurement_notes_*_20261031.md）。thd_out は 50〜300mV の [出力 peak, THD%]、h2 は 50〜300mV の 2 次の向き（度）
MEASURED = {
    'JJ':  dict(gain_db=30.85, vk=19.3, peak400=[6.85, -9.45],
                out=[1.71, 3.39, 5.01, 6.43, 7.54, 8.35], thd=[2.38, 1.80, 1.72, 4.68, 8.43, 12.4],
                h2=[-4, -6, 179, 175, 175, 175]),
    'SYL': dict(gain_db=31.48, vk=18.4, peak400=[6.99, -9.68],
                out=[1.85, 3.61, 5.19, 6.59, 7.76, 8.59], thd=[1.93, 4.13, 6.59, 9.44, 12.67, 15.74],
                h2=[174, 175, 175, 175, 175, 175]),
    'GD':  dict(gain_db=31.56, vk=20.4, peak400=[7.05, -9.15],
                out=[1.87, 3.64, 5.23, 6.64, 7.87, 8.61], thd=[2.06, 4.39, 6.90, 9.55, 12.21, 14.35],
                h2=[176, 176, 176, 175, 176, 176]),
    'UNK': dict(gain_db=30.17, vk=18.4, peak400=[6.60, -9.63],
                out=[1.61, 3.15, 4.58, 5.85, 6.91, 7.86], thd=[1.37, 3.37, 6.38, 9.70, 12.91, 16.54],
                h2=[176, 174, 174, 174, 174, 175]),
}


def check_param_lib(path=PARAM_LIB):
    """6V6_param.lib の係数（.param c_...）が全部入っているか確かめる。空欄があれば止める"""
    txt = open(path, encoding='ascii').read()
    names = re.findall(r'^\.param\s+(c_\w+)\s*=', txt, re.M | re.I)
    empty = re.findall(r'^\.param\s+(c_\w+)\s*=\s*$', txt, re.M | re.I)
    if not names:
        raise ValueError('6V6_param.lib に係数の行（.param c_...）が見つからない: ' + path)
    if empty:
        raise ValueError('6V6_param.lib の係数が空欄のまま: %s。README の手順で 6V6.inc から写して入れる（%s）'
                         % (', '.join(empty), path))


def make_cir(params, tag, work_dir):
    """テンプレートの 6V6 を 6V6P に替え、.four を V(spk) だけにした .cir を書く"""
    s = open(TEMPLATE, encoding='utf-8').read()
    pstr = ' '.join('%s=%.10g' % kv for kv in sorted(params.items()))
    if 'XV2 p2 bp2 g2 k2 6V6\n' not in s:
        raise ValueError('テンプレートに XV2 の行が見つからない: ' + TEMPLATE)
    s = s.replace('XV2 p2 bp2 g2 k2 6V6\n', 'XV2 p2 bp2 g2 k2 6V6P %s\n' % pstr)
    s = s.replace('.lib tubes.lib\n', '.lib tubes.lib\n.lib "%s"\n' % PARAM_LIB)
    s = re.sub(r'\.step param ain list .*\n', '.step param ain list %s\n' % ' '.join('%g' % a for a in LEVELS), s)
    s = s.replace('.four 1k 9 V(spk) V(p1a) V(g2)', '.four 1k 9 V(spk)')
    # 配布版: 作業フォルダに書いた .cir からも同じフォルダのライブラリを読めるよう、絶対パスにする
    # （このフォルダに無いものは書き換えず、LTspice のライブラリから探させる）
    for lib in LOCAL_LIBS:
        path = os.path.join(HERE, lib)
        if os.path.exists(path):
            s = s.replace('.lib %s\n' % lib, '.lib "%s"\n' % path)
    fn = os.path.join(work_dir, 'fit_%s.cir' % tag)
    open(fn, 'w', encoding='utf-8').write(s)
    return fn


def parse_log(fn):
    """.log から、レベルごとの基本波（peak）・THD・2 次の向きと、カソード電圧を読む"""
    # LTspice -b の .log は UTF-16 と 1 バイト文字が混ざるので、NUL を消して latin-1 で読む（° は化けるが使わない）
    txt = open(fn, 'rb').read().replace(b'\x00', b'').decode('latin-1').replace('\r\n', '\n')
    sec = txt.split('Fourier components of V(spk)')
    if len(sec) < 2:
        raise RuntimeError('.four の結果がない（シミュレーション失敗？）: ' + fn)
    rows = []
    for st in re.split(r'\nstep \d+', sec[1])[1:]:
        h = {}
        for l in st.splitlines():
            m = re.match(r'\s*(\d)\s+\S+\s+(\S+)\s+\S+\s+([-\d.e+]+)', l)
            if m:
                h[int(m.group(1))] = (float(m.group(2)), float(m.group(3)))
        a1, p1 = h[1]
        thd = np.sqrt(sum(h[n][0] ** 2 for n in range(2, 10))) / a1 * 100
        # .four の位相は h2_phase.py と符号が逆（four_h2_phase.py と同じ扱い）
        th2 = -((h[2][1] - 2 * p1 + 180) % 360 - 180)
        rows.append((a1, thd, th2))
    vk, pmax, pmin = [[float(x) for x in re.findall(r'^\s*\d+\s+(\S+)', txt.split('Measurement: %s\n' % n)[1].split('\n\n')[0], re.M)]
                      for n in ('vk2', 'spkmax', 'spkmin')]
    return rows, vk, pmax, pmin


def metrics(rows, vk, pmax, pmin):
    """実測と同じ指標: 20mV の利得、3/5/7V peak の THD、50〜300mV の 2 次の向き、20mV のカソード電圧"""
    out = [r[0] for r in rows]
    thd = [r[1] for r in rows]
    return dict(gain_db=20 * np.log10(out[0] / LEVELS[0]),
                thd_at=[float(np.interp(v, out[1:], thd[1:])) for v in OUT_PEAKS],
                h2=[r[2] for r in rows[1:]], vk=vk[0], out=out, thd=thd,
                peak400=[pmax[LEVELS.index(0.4)], pmin[LEVELS.index(0.4)]])


def run_one(params, tag, work_dir):
    cir = make_cir(params, tag, work_dir)
    log = cir[:-4] + '.log'
    p = subprocess.run([LTSPICE, '-b', cir], timeout=TIMEOUT_S)
    if p.returncode != 0 or not os.path.exists(log):
        raise RuntimeError('LTspice が失敗: %s (code %s)' % (cir, p.returncode))
    m = metrics(*parse_log(log))
    # .raw は大きいので消す（指標は .log だけで計算できる）
    for ext in ('.raw', '.op.raw', '.log.raw'):
        f = cir[:-4] + ext
        if os.path.exists(f):
            os.remove(f)
    return m


def run_sets(param_sets, work_dir, prefix='p'):
    """パラメータの組のリストを並列で実行し、[(params, metrics or 例外)] を返す"""
    check_param_lib()
    os.makedirs(work_dir, exist_ok=True)
    with cf.ThreadPoolExecutor(PARALLEL) as ex:
        futs = [ex.submit(run_one, ps, '%s%03d' % (prefix, i), work_dir) for i, ps in enumerate(param_sets)]
        res = []
        for ps, f in zip(param_sets, futs):
            try:
                res.append((ps, f.result()))
            except Exception as e:
                res.append((ps, e))
    return res


def h2_same(model_deg, meas_deg):
    """2 次の向きが同じか（cos の符号で判定）"""
    return [np.cos(np.radians(a)) * np.cos(np.radians(b)) > 0 for a, b in zip(model_deg, meas_deg)]


def score(m, tube, gain_offset_db=0.0):
    """指標ごとの差と合否。gain_offset_db は前段（12AX7・Volume）の共通のずれ（実測 − モデル）。
    None なら利得を cost に入れない（前段のずれが決まる前の探索用）"""
    t = MEASURED[tube]
    t_thd = [float(np.interp(v, t['out'], t['thd'])) for v in OUT_PEAKS]
    d = dict(gain=m['gain_db'] + (gain_offset_db or 0.0) - t['gain_db'],
             thd=[a - b for a, b in zip(m['thd_at'], t_thd)],
             vk=m['vk'] - t['vk'],
             h2=h2_same(m['h2'], t['h2']))
    d['ok'] = dict(gain=abs(d['gain']) <= 0.3, thd=all(abs(x) <= 1.0 for x in d['thd']),
                   h2=all(d['h2']), vk=abs(d['vk']) <= 0.5)
    # 探索用の 1 つの値（小さいほど良い）: 各指標を許容幅で割った二乗和 + 向きの不一致
    gain_term = 0.0 if gain_offset_db is None else (d['gain'] / 0.3) ** 2
    d['cost'] = (gain_term + sum((x / 1.0) ** 2 for x in d['thd']) + (d['vk'] / 0.5) ** 2
                 + 4 * sum(not x for x in d['h2']))
    return d


def append_results(res, path, stage):
    """探索の記録: 1 行 1 条件の JSON Lines で追記する"""
    import json, datetime
    with open(path, 'a', encoding='utf-8') as f:
        for ps, m in res:
            rec = dict(time=datetime.datetime.now().isoformat(timespec='seconds'), stage=stage, params=ps)
            if isinstance(m, Exception):
                rec['error'] = str(m)
            else:
                rec['metrics'] = {k: (np.round(v, 4).tolist() if isinstance(v, list) else round(float(v), 4)) for k, v in m.items()}
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    # python fit_6v6.py <stage 名> <パラメータの組の JSON（リスト）> <作業フォルダ>
    import sys, json
    stage, sets, work = sys.argv[1], json.loads(sys.argv[2]), sys.argv[3]
    res = run_sets(sets, work, prefix=stage + '_')
    append_results(res, LOG_PATH, stage)
    for ps, m in res:
        if isinstance(m, Exception):
            print(ps, 'ERROR', m)
            continue
        line = ' '.join('%s %+.1f/%+.1f/%+.1f %+.2fV %s' % ((t,) + tuple(score(m, t)['thd']) + (score(m, t)['vk'],
                        ''.join('o' if x else 'x' for x in score(m, t)['h2']))) for t in MEASURED)
        print(json.dumps(ps), 'gain %.2fdB vk %.2fV pk400 %+.2f/%.2f thd3/5/7 %s |' % (
            m['gain_db'], m['vk'], m['peak400'][0], m['peak400'][1], np.round(m['thd_at'], 2).tolist()), line)
