# 05_6V6_compare: Fender 5F1 Champ の 6V6 差し替え（実測データ・モデル・探索スクリプト）

Note の記事「Fender 5F1 Champ の 6V6 を 4 本差し替えて実測、LTspice の真空管モデルを AI で合わせ込む」（#5）の配布物です。
記事: 【公開後に URL を記入】

Data and scripts for the Note article #5 (Japanese): measurements of four 6V6 tubes in a Fender 5F1 Champ,
the LTspice model of the amp, and the parameter search that fits the 6V6 model to each tube.

## 中身

| ファイル・フォルダ | 説明 |
|---|---|
| `measurement_data/tube_JJ6V6S/` など 4 フォルダ | 6V6 4 本（JJ 6V6S、SYLVANIA 6V6GT、Golden Dragon 6V6GTA、銘柄不明）の実測（2026-10-31）。下の「実測データ」 |
| `5F1_Actual_TRAN_Vol5Levels_20261031.cir` | 実機モデル（LTspice のネットリスト）。Volume 5、1kHz、入力 20〜600mV peak の 9 レベルを `.step` で過渡解析する |
| `6V6_param.lib` | 6V6 のモデル `6V6P`。中林歩氏の 6V6 モデルの式にパラメータを付けたもの。**係数は空欄**なので、下の「必要なもの」の手順で入れてから使う。係数を入れれば、既定値で元のモデルと同じ結果になる。v2（下の「6V6_param.lib の v2」） |
| `TANGO_M757.lib` | 出力トランス TANGO M-757 のモデル（データシートの値から作ったもの。7k 端子と 8Ω 端子を使う） |
| `fit_6v6.py` | パラメータ探索のスクリプト（Python）。パラメータの組ごとに LTspice を実行し、実測と同じ指標を計算する |
| `fit_6v6_log_percent_20261031.jsonl` | 探索の記録（探索の 73 条件と、v2 での再計算 6 行の計 79 行。1 行 1 条件の JSON）。パラメータは元の値に対する %（小数 2 桁）で書いてある。結果（`metrics`）は記事で使ったそのまま |
| `README.md` | このファイル |

真空管のモデル `tubes.lib`（12AX7・6V6）は入っていません。下の「必要なもの」の手順で用意してください。

## 必要なもの

- **LTspice**（Analog Devices。LTspice 26.1.1 で動作を確認）
- **真空管のモデル（12AX7 と 6V6）**: 中林歩氏の「SPICE用真空管モデル」を使います
  1. Ayumi's Lab.（http://ayumi.cava.jp/audio/ ）から Windows 用の `tubemodel_3.20_win.zip` を入手する
  2. zip の中の `12AX7.inc` と `6V6.inc` を 1 つのファイルにつなげ、名前を `tubes.lib` にする
  3. `tubes.lib` の中の `^` をすべて `**` に置き換える（LTspice は `^` をべき乗ではなく XOR と解釈し、計算が壊れる）
  4. `tubes.lib` をこの README と同じフォルダに置く
  5. `6V6_param.lib` の係数を入れる（下の「6V6_param.lib に係数を入れる」）。.cir を動かすだけなら不要（.cir は `tubes.lib` の 6V6 を使う）。`fit_6v6.py` を使うときに必要
  - ピン順は 12AX7 が `A G K`、6V6 が `A G2 G1 K` で、.cir と同じです
  - この手順で作った `tubes.lib` で、.cir の結果（THD・出力・直流）が記事の値と一致することを確かめています（差は THD で 0.0002 ポイント以下）
- **Python 3 と numpy**（`fit_6v6.py` を使う場合）: `pip install numpy`

### 6V6_param.lib に係数を入れる

`6V6_param.lib` は、式とパラメータだけが入っていて、6V6 の係数は空欄です。係数は公開版から写して入れます。

1. 上の手順 1 の `tubemodel_3.20_win.zip` の中の `6V6.inc` を、テキストエディタで開く
2. `6V6_param.lib` をテキストエディタで開き、`* ---- COEFFICIENTS` の下にある `.param c_gg=` などの空欄 17 個に、`6V6.inc` の数値を写す。どの行のどの数値を写すかは、`6V6_param.lib` の冒頭のコメント（`HOW TO FILL IN THE COEFFICIENTS`）の一覧のとおり。例: `c_gg` は `6V6.inc` の `BGG` の行の `V(G1,K)+` の後ろの数値
   - 数値は書いてあるとおりに写す（丸めない）。容量の 4 個（`c_ga`・`c_gk`・`c_12`・`c_ak`）は `p` を付けたまま写す
   - `BM1` の行の指数（`^` の後ろ）は写さない。`6V6_param.lib` の中で `1.5 − c_ex` として計算する
3. 保存する（文字コードは ASCII のまま）

- 空欄が残っていると、`fit_6v6.py` は LTspice を動かす前に「係数が空欄のまま」と表示して止まります
- 係数を入れた `6V6_param.lib` の `6V6P` は、パラメータを指定しなければ元の `6V6` と同じ結果になります（探索の記録の 1 行目と同じ値になることを確かめています）

### 6V6_param.lib の v2（2026-10-31）

- 元のモデルは、グリッド電圧が負のときと正のときで別の式を使い、グリッド 0V でつながるようになっています。探索で動かした `ex_pct`・`mu2_pct` は負の側の式にしか入っていないため、最初の版（v1）では、記事の値にするとグリッド 0V の境目で電流が 1.25〜1.8 倍跳ぶ段差がありました
- v2 では、正の側の式（`BP` の行）に補正を掛けて、境目でつながるようにしました。補正に使う係数は、空欄の 17 個のうちの `c_m1`・`c_m2`・`c_mu2`・`c_ex` で、新しく写す係数はありません。負の側の式（ふだんの動作点の式）は変えていません
- 記事で選んだ 4 組を v2 で計算し直すと、入力 20〜400mV の結果は v1 と同じでした（記録の 76〜79 行目と 64・69・72・73 行目。差は THD の最後の桁で 0.0001 ポイント。`stage` が `recheck_v2`）。この範囲では 6V6 のグリッドが 0V に届かないためです。補正が効くのは、入力 600mV のようにグリッドが 0V を超えるときです

置き方（すべて同じフォルダ）:

```
05_6V6_compare/
  5F1_Actual_TRAN_Vol5Levels_20261031.cir
  6V6_param.lib
  TANGO_M757.lib
  tubes.lib            <- 自分で用意する
  fit_6v6.py
  fit_6v6_log_percent_20261031.jsonl
  measurement_data/
```

## 使い方

### 1. 実機モデルを動かす

LTspice で `5F1_Actual_TRAN_Vol5Levels_20261031.cir` を開いて実行するか、コマンドで実行します（約 1〜2 分）。

```
"C:\Program Files\ADI\LTspice\LTspice.exe" -b 5F1_Actual_TRAN_Vol5Levels_20261031.cir
```

同じフォルダに `.log` と `.raw` ができます。`.log` には `.meas`（直流、出力のピークなど）と `.four`（スピーカー端子・V1A プレート・6V6 グリッドの 9 次までの高調波）がレベルごとに出ます。`.raw` は 1 本 約 50MB です。

### 2. THD と 2 次の向きを読む

`fit_6v6.py` の `parse_log()` で `.log` を読めます（このフォルダで実行）。

```
python -c "import fit_6v6; rows, vk, pmax, pmin = fit_6v6.parse_log('5F1_Actual_TRAN_Vol5Levels_20261031.log'); [print(r) for r in rows[:9]]"
```

- `rows` の最初の 9 個が、スピーカー端子の (基本波の振幅 V peak, THD %, 2 次の向き 度) で、入力 20・50・100・150・200・250・300・400・600mV の順です（10 個目以降は V1A プレートと 6V6 グリッド）
- `vk` は 6V6 のカソード電圧、`pmax`・`pmin` はスピーカー端子のピーク（どれもレベルの順）
- THD は 2〜9 次。2 次の向きは下の「2 次の向き」の定義で、実測と比べられる向きにそろえてあります

### 3. 6V6 のパラメータを変えて試す

```
python fit_6v6.py <名前> "<パラメータの組の JSON のリスト>" <作業フォルダ>
```

例（元のモデルと、記事の SYLVANIA に合わせた値の 2 条件）:

```
python fit_6v6.py test "[{}, {\"mu2_pct\": -3.12, \"ex_pct\": 10.12}]" work
```

- 先に `6V6_param.lib` に係数を入れておいてください（上の「6V6_param.lib に係数を入れる」）
- パラメータの書き方: `vofs_pct`・`ex_pct`・`mu2_pct`・`s0_pct` は元の値に対する変化（%。0 で元の値）、`kp`・`kn` は元の式に掛ける倍率（1 で元の式）、`s1`・`sw`・`i0` は追加した項の値（`s1` が 0 なら追加項なし）
- 指定しなかったパラメータは `6V6_param.lib` の既定値（元のモデル）のままです。パラメータの意味は `6V6_param.lib` の冒頭のコメントと記事の表を見てください
- 1 条件ごとに .cir を作業フォルダに書いて LTspice を実行し、4 本の実測との差（THD 3/5/7V peak、カソード電圧、2 次の向き）を画面に出します。2 条件で約 1 分半（LTspice を 2 本まで同時に動かす。`PARALLEL` で変えられるが、増やしすぎると遅くなる）
- 結果は同じフォルダの `fit_6v6_log_new.jsonl` に追記されます（配布した `fit_6v6_log_percent_20261031.jsonl` には書き足しません）
- LTspice の場所が違うときは、環境変数 `LTSPICE` に LTspice.exe のパスを入れてください
- `from fit_6v6 import run_sets, score` として、ほかのスクリプトから使うこともできます（`score()` が記事の 4 つの指標の判定）
- 上の例の結果は、配布した記録の 1 行目（37 行目も同じ条件）と同じ値、72 行目とほぼ同じ値（THD の差 0.003 ポイント以内）になることを確かめています。記録の % は小数 2 桁に丸めてあるので、再実行の結果は丸めの分だけ記録と少しずれます

### 4. 探索の記録を読む

`fit_6v6_log_percent_20261031.jsonl` は 1 行 1 条件です。

- `stage`: 探索の回（`sens` 感度、`round1`〜`round5`）。74〜79 行目の `recheck_v2` は、記事で選んだ 4 組を v2 の `6V6_param.lib` で計算し直したもの（74・75 行目は 400 秒で打ち切られた実行で、`metrics` の代わりに `error` が入っている。78・79 行目がその再実行）
- `params`: 既定値から変えたパラメータ。書き方は `fit_6v6.py` に渡すときと同じ（`*_pct` は元の値に対する %、`kp`・`kn` は倍率、`s1`・`sw`・`i0` は追加した項の値）。そのまま `fit_6v6.py` に渡せば同じ条件を再実行できます
- `metrics`: `gain_db`（入力 20mV の 1kHz の利得）、`thd_at`（出力 3・5・7V peak の THD、%）、`h2`（入力 50mV〜の 2 次の向き、度）、`vk`（カソード電圧）、`out`・`thd`（入力 20mV〜の基本波と THD）、`peak400`（入力 400mV の正・負のピーク。round2 以降）
- `time` は実行した日時です
- 記事で選んだ条件は 72 行目（SYLVANIA）、73 行目（Golden Dragon）、64 行目（銘柄不明）、69 行目（JJ、途中）です

## 実測データ

`measurement_data/tube_<球>/` に 1 本分ずつ入っています。測定の条件と、測った値の一覧は `measurement_notes_<球>_20261031.md`（日本語）にあります。測定記録は Claude が測定しながら書いた記録で、文中の「ユーザー」は著者のこと、`adp_config`・`scope_measure`・`thd_spectrum` は Claude から測定器を操作したときの命令の名前です。

- アンプ: Fender 5F1 Champ（著者の実機）。NFB なし、C7 0.1μF、R9 220kΩ、出力トランス TANGO M-757 の 7k 端子、整流管 5AR4、Input 1、8Ω ダミーロード、Volume 5 相当（ワイパー〜GND 49kΩ）。差し替えたのは 6V6 だけ
- 測定器: Digilent Analog Discovery Pro ADP3450（WaveForms）。CH1（×1 プローブ）が入力、CH2（×10 プローブ）がスピーカー端子
- 信号: 1kHz 正弦波。振幅はピーク値

| フォルダ | 中身 |
|---|---|
| `gain/` | 入力 20mV の波形（`*_scope.csv`）。利得を求めたもの。JJ の 15:12〜15:13 の 3 つは Volume がずれていたときの無効な測定（測定記録を参照） |
| `bode/` | 周波数特性（`*_bode.csv`: 周波数 Hz、利得 dB、位相 度。10Hz〜100kHz、61 点、入力 20mV）と、その画面（`.png`） |
| `thd_level/` | 入力 50〜300mV の波形（`*_scope.csv`）と、THD を測ったスペクトルの画面（`*_thd.png`） |
| `max_out/` | 入力 400mV・600mV の波形（`*_scope.csv`）とその画面（`.png`） |

- scope の CSV は WaveForms が書き出した形式です。`#` で始まる行がヘッダー、続いて `Time (s), Channel 1 (V), Channel 2 (V), Channel 3 (V), Channel 4 (V)`。**Channel 2 はプローブの ×10 を掛ける前の値**です（スピーカー端子の電圧は 10 倍する）。Channel 3・4 はこの測定では使っていません
- `bode/*_bode.csv` の利得は、プローブの ×10 を入れたあとの「スピーカー端子 ÷ 入力」です（1kHz の値が記事の利得と同じ）
- `.png` は WaveForms の画面をそのまま保存したもので、表示の目盛はプローブの ×10 を掛ける前の値です。周波数特性の画面は表示範囲の上限（+10dB）で切れているので、値は CSV を見てください
- ヘッダーの機器のシリアル番号は消してあります（`#Serial Number: (removed)`）
- 1 つのファイルは 32768 点（6.25MS/s、約 5.2ms = 5 周期）

### 2 次の向き

記事の「2 次の向き」は、波形に 9 次までの高調波を最小二乗で当てはめ、「2 次の位相 − 2 × 基本波の位相」（cos 基準）で求めた角度です。180° 付近と 0° 付近では、歪みの出方が上下逆になります。scope の CSV は 5 周期と短いので、周波数は 990〜1010Hz の範囲で探して決めています。

## 出典の書き方

このデータやスクリプトを使って何かを公開するときは、次のように出典を書いてください。

- このフォルダの実測データ・モデル・スクリプト: 「Note #5『Fender 5F1 Champ の 6V6 を 4 本差し替えて実測、LTspice の真空管モデルを AI で合わせ込む』の配布物（【公開後に URL を記入】）」
- 6V6・12AX7 のモデル（`6V6_param.lib` の元のモデルと `tubes.lib`）: 「中林歩氏の SPICE用真空管モデル（Ayumi's Lab. http://ayumi.cava.jp/audio/ ）」

`6V6_param.lib` に入れる係数は、公開版（`tubemodel_3.20_win.zip` の `6V6.inc`）から写してください。

## 注意

- 実機の B+ は約 340V あります。真空管アンプの中を触るときは、電源を切り、平滑コンデンサの放電を確かめてからにしてください
- モデルは著者の実機と、その日の 4 本の球に合わせたものです。同じ銘柄の球でも個体差があり、同じ値になるとは限りません
