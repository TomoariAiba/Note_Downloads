---
name: ltspice-simulation
description: LTspice（MCPブリッジ経由）で回路シミュレーションを行い、ネットリスト(.cir)・回路図(.asc)・結果レポート(.md)・波形グラフ(SVG)をプロジェクトフォルダに残し、作業ログを書く。真空管アンプ（ギターアンプ・オーディオ、12AX7/6V6/EL34等）に特に強い。「〇〇の回路をシミュレーションして」「LTspiceで動作を確認したい」「このアンプの出力・歪み・周波数特性を見たい」「回路の定数を変えたらどうなるか比べたい」「Fender系アンプの回路を解析して」「LTspiceの回路図を作って」といった依頼、回路図や回路名と入力信号の条件が示されたとき、オペアンプ・電源・フィルタ・トランジスタ回路の過渡/AC/DC解析を頼まれたときは、LTspiceと明示されていなくても必ずこのスキルを使う。
---

# LTspice 回路シミュレーション

回路を LTspice で解き、**ユーザーが後から開いて・再実行して・確かめられる形**で結果を残すためのスキル。
シミュレーション結果は、もっともらしい数字が出ても前提が違えば意味がない。
だから「前提を明示する → 解く → 現実の値と突き合わせる → 正直に報告する」の流れを大事にする。

## 成果物（毎回すべて作る）

保存先は作業中のプロジェクトフォルダの `output/` とする（CLAUDE.md に保存先の決まりがあれば、そちらに従う）。

| 成果物 | ファイル名 | 役割 |
|---|---|---|
| ネットリスト | `<Circuit>_<YYYYMMDD>.cir` | 解析の正本。テキストなので差分が追いやすく、接続ミスが起きにくい |
| 回路図 | `<Circuit>_<YYYYMMDD>.asc` | ユーザーが LTspice の画面で回路を見て、そのまま実行・改造するためのもの |
| 回路図の生成スクリプト | `make_<circuit>_asc.py` | 回路図を作り直すとき用 |
| 結果レポート | `<回路名>シミュレーション結果_<YYYYMMDD>.md` | 条件・仮定・数値・考察 |
| 波形グラフ | `<Circuit>_<内容>_<YYYYMMDD>.svg` | レポートに埋め込む。`<内容>` は `GainCompare`・`Waveform` など内容を表す語にし、.cir の `_AC`/`_TRAN` と大文字小文字だけが違う名前にしない |
| 作業ログ | CLAUDE.md で決めた場所（決まりがなければプロジェクトフォルダの `作業ログ.md`） | 次回の作業の引き継ぎ |

- LTspice が読むファイルとグラフ（.cir / .asc / .svg）は **ASCII の名前**にする。日本語名は Edge のヘッドレス表示などで失敗することがある。レポートは日本語名でよい
- .ac と .tran の両方が必要なときは、.cir を `_AC` / `_TRAN` の2本に分ける（1つのネットリストで実行できる解析は1種類）
- LTspice は実行時に `.log` `.raw` `.op.raw` `.net` と、測定値のデータベース `<名前>.db` を自動で書く
  - 波形グラフ用に書き出す .db とは別物。グラフ用の .db は scratchpad に置き、output の .db と混ぜない

## 全体の流れ

1. 依頼内容と前提を整理する
2. LTspice リファレンスを確認し、MCP ツールを読み込む
3. 回路定数とモデルを決める
4. ネットリスト（.cir）を書く
5. 実行してログを読む
6. 妥当性を確認する（ここを飛ばさない）
7. 回路図（.asc）を作り、.cir と同じ回路かを照合する
8. 波形グラフを作り、目で見て確認する
9. レポートを書く
10. 作業ログを書き、ユーザーに報告する

- 真空管回路のとき: 手順 3〜7 の前に [references/tube-amps.md](references/tube-amps.md) を読む
- 回路図を作るとき: [references/schematic.md](references/schematic.md) を読む
- 手本: `references/examples/` にあるファイル
  - `5F1_Champ.cir`: 真空管アンプの全体（電源・出力トランス・NFB込み）
  - `OpAmp_NonInv_G10.cir`: OPアンプ回路の .cir
  - `make_opamp_asc.py`: その回路図を作るスクリプト

---

## 1. 依頼内容と前提を整理する

最初に次を決める。依頼に書かれていないものは、もっともらしい既定値を選んでレポートに「仮定」として明記する。
質問で手を止めるのは、答えによって作業が大きく変わる場合だけにする。

| 項目 | 例 | 既定の考え方 |
|---|---|---|
| 回路 | 5F1 Champ、非反転アンプ、降圧電源 | 定番回路なら標準値を調べる |
| 入力信号 | 1kHz 200mV の正弦波 | **「200mV」がピーク値か実効値かは曖昧**。ピーク値として扱い、レポートで明記する（「1Vpp」はピーク・ピーク値として明確） |
| 解析の種類 | 過渡（.tran）、周波数特性（.ac）、DC 掃引（.dc） | 波形・歪み → .tran、周波数特性 → .ac、特性カーブ → .dc |
| 振る条件 | ボリューム位置、負荷、部品のあり・なし | 依頼が比較なら比較の軸だけを振る。そうでなく、結果が条件で大きく変わるとき（ギターアンプのボリュームなど）は、意味のある 3〜4 点を `.step` で振る |
| 見たい量 | 出力電力、THD、利得、帯域、動作点 | 依頼の目的から逆算する |

## 2. LTspice リファレンスと MCP ツール

LTspice MCP サーバーは、回答や編集の前にリファレンスを読むよう求めている。
`mcp__ltspice__list_ltspice_reference_docs` → 必要なものを `mcp__ltspice__get_ltspice_reference` で読む。
よく使うのは次の3つ。
- `SIMULATION-COMMANDS-REFERENCE.md`
- `MEAS-REFERENCE.md`
- `CIRCUIT-ELEMENTS-REFERENCE.md`

ツールが deferred のときは、`ToolSearch` で一度にまとめて読み込む。対象は次のツール。
- `mcp__ltspice__status`、`open_design`、`start_simulation`、`set_design_content`
- `get_spice_log`、`get_schematic_netlist`、`get_raw_info`、`read_raw_waveforms`、`export_raw_waveforms`

`mcp__ltspice__status` で、接続先が次のどちらかを確認する。
- **ユーザーの GUI**: 開いたファイルがユーザーの画面にも出る。最後に「保存せず閉じてよい」と伝える
- **バックグラウンドの LTspice**: 画面には出ない。成果物の .asc はユーザーが自分で開く

## 3. 回路定数とモデルを決める

- **定番回路**（市販アンプ、アプリケーションノートの回路）: WebSearch / WebFetch で定数を集める
  - 出典が食い違う定数（例: 5F1 の V1A カソードの 25µF）は、どちらを採ったかと理由をレポートに書く
  - 公表されている実測電圧（ボルテージチャートなど）があれば控えておき、手順 6 で突き合わせる
  - 出典 URL はレポートの「出典」に残す
- **教科書的な回路**（非反転アンプ、RC フィルタなど）: 調べものは要らない。定数は依頼から決める
  - 部品の代表値（データシートの GBW など）を記憶から使ったら、その旨をレポートに書く
- **OPアンプのモデル**: 型番の指定がなければ、LTspice 付属の汎用モデル `UniversalOpAmp2`（`.lib UniversalOpAmp2.lib`、サブサーキット名 `level2`）を使う
  - ADI 製品の .sub の多くは暗号化されていて、ピン順やパラメータが読めない
  - ピン順は `In+ In- V+ V- OUT`。例:
    `XU1 in inv vcc vee out level2 Avol=200k GBW=3Meg Slew=13Meg Ilimit=25m Rail=1.5 Vos=0`
  - 型番の指定があれば `lib/sub` にあるか探す。無ければ汎用モデルに代表値（GBW、スルーレート）を入れて代用し、そう書く
- **真空管**: ユーザーが用意したモデルのライブラリを使う。ピン順はライブラリごとに違うので、`.SUBCKT` の行で確かめる（[references/tube-amps.md](references/tube-amps.md)）

## 4. ネットリスト（.cir）を書く

解析の正本はネットリストにする。テキストなので、部品と接続を1行ずつ確かめられる。回路図は手順 7 でここから作る。

書き方の約束:
- 先頭のコメントに、回路名・入力条件・**仮定（モデル、負荷、省略したもの）**を書く。ファイル単体で前提が分かるようにする
- ブロックごとに `*---- 入力 ----` のような区切りを入れる。部品名は元の回路図の番号（R1, C3…）に合わせる
- 振る値は `.param` と `.step param` で書く
  - 可変抵抗は `.param ratio=...` で2本の抵抗に分ける
  - 分圧比が 0 や 1 になると抵抗が 0Ω になり「Resistance must not be zero」で止まる。`min(max(...,1e-4),0.9999)` で挟む
- 部品の「あり・なし」の比較は、`.step param` と値の切り替えで書く:
  ```spice
  .param byp=1
  .step param byp list 0 1
  C7 k1a cx 25u
  RCX cx 0 {if(byp,1m,1T)}      ; byp=1 で接続、0 で実質オープン
  ```
- 中身は ASCII のみにする（日本語コメントは文字化けや読み込み失敗の原因になる）

測定は `.meas` で書き、ログから数値を読めるようにする。

**過渡解析**: 電源やバイアスが落ち着いた後の区間（`FROM`〜`TO`）で測る。
```spice
.tran 0 0.6 0.5 5u                 ; 0.5s 以降だけ保存して raw を小さくする
.meas TRAN vrms RMS V(out) FROM 0.5 TO 0.6
.meas TRAN pout PARAM vrms*vrms/8
.meas TRAN vpp  PP  V(out) FROM 0.5 TO 0.6
.meas TRAN vdc  AVG V(node) FROM 0.5 TO 0.6
.four 1k 9 V(out)                  ; THD と高調波
```

**AC 解析**:
```spice
.options meascplxfmt=polar          ; これが無いと位相も dB 表記で出る
.ac dec 100 1 10Meg
.meas AC g1k  FIND mag(V(out)) AT 1k
.meas AC f3db WHEN mag(V(out))=g1k/sqrt(2) FALL=1   ; 高域側の -3dB 点
.meas AC fl   WHEN mag(V(out))=g1k/sqrt(2) RISE=1   ; 低域側の -3dB 点（低域で落ちる回路のみ）
.meas AC ph3  FIND ph(V(out)) AT f3db
```

`.meas` の注意:
- `WHEN ... CROSS/RISE/FALL` は、最初に条件を満たした点を拾う
  - 直流まで平坦な段に「低域の -3dB」を測らせると、高域側の点が返ってくる
  - 結果が物理的に妥当かは、必ずグラフで確かめる
  - 解析範囲の中で条件を満たさないと「FAIL'ed」になる（例: 1 MHz まで高域が −3dB 落ちない段の `FALL=1`）。エラーではないので、そう報告するか範囲を広げる
- `PARAM` の式の中で `MAX(V(x))-MIN(V(x))` のような波形関数は使えない（「Expected ","」エラー）
  - PP などで個別に測ってから PARAM で組み合わせる
- 平滑コンデンサが大きい回路は、`.ic V(node)=...` で予想電圧を与えると、落ち着くまでの時間を短くできる

## 5. 実行してログを読む

```
mcp__ltspice__open_design(path)        # 実行前に開く
mcp__ltspice__start_simulation(path)
```

完了を待つには、ログに終了の印が出るまで Bash で待つ。
- ログは NUL 文字を含むことがあるので、`tr -d '\000'` で除いてから判定する
- 上限時間（下の例では 600 秒）を付ける
- エラーで止まったときも抜けられるよう、エラーの文言も待つ条件に入れる（`No such node.` は「Error」を含まない）
```bash
f=<.logのパス>; for i in $(seq 600); do [ -f "$f" ] && tr -d '\000' < "$f" | grep -q -E "Total elapsed|must not|Singular|Fatal|rror|No such|nknown" && break; sleep 1; done; tr -d '\000' < "$f"
```

つまずきやすい点（どれも実際に起きたもの）:
- **一度に実行できるシミュレーションは1つだけ**
  - 実行中に別のファイルを始めると「A simulation is already running」になる
  - 1つ終わるのを待ってから次を始める
- **既に開いているファイルは、`open_design` しても再読み込みされない**
  - ディスク上で書き換えたら、`set_design_content` で中身を送り直してから実行する
- **再実行の前に古い .log を消す**。残っていると、待ち合わせが古いログで抜けてしまう
- **`.op` だけの raw は MCP で読めないことがある**
  - 動作点は `.meas` で出すか、`.dc` でダミー電源を2点掃引して確認する
  - 1点だけの掃引は「only one point」エラーになる
- **`.tran` で保存開始時刻を指定すると、`export_raw_waveforms` の時刻は保存開始を 0 とした値になる**
  - 例: `.tran 0 0.6 0.5` なら 0〜0.1s になる
  - `x_min`/`x_max` はこの値で指定する

## 6. 妥当性を確認する

数字が出ただけでは完了にしない。次を確認し、レポートに表で残す。

| 回路 | 確認すること |
|---|---|
| 共通 | 直流動作点（電源電圧、各段のバイアス）を公表値か手計算と比べる |
| OPアンプ | 閉ループ利得 1/(β+1/Avol)、帯域 ≈ GBW/ノイズゲイン、出力振幅が電源−Rail に収まるか |
| トランジスタ・真空管 | 動作点、小信号利得（真空管は μ·Ra/(Ra+rp+(μ+1)Rk) など）、素子の定格（損失、耐圧） |
| 電源 | 出力電圧、リップル、負荷電流 |

- 判定の目安:
  - 抵抗・OPアンプなど精度の高い部品の回路は、理論との差が数% 以内なら妥当とする
  - 真空管や個別トランジスタは個体差が大きいので、±20% 程度なら「ばらつきの範囲」とする。どちらの判断をしたかを書く
- **現実離れした値**（出力電力が定格の2倍、電圧が素子の定格を超えるなど）を見つけたら、原因の仮説（モデルの理想化、損失の省略など）を添えて正直に報告する
  - 隠したり、合うように定数をこっそりいじったりしない

## 7. 回路図（.asc）を作り、照合する

詳しい手順とレイアウトのこつは [references/schematic.md](references/schematic.md) にある。概要:

1. 同梱の `scripts/asc_builder.py` を使い、`make_<circuit>_asc.py` を書く
   - ピン座標はシンボル定義から自動計算されるので、手で計算しない
   - 信号は左から右、電源は上、GND は下に配置する。遠い場所どうし（B+、帰還、電源レール）はネットラベルでつなぐ
   - .cir の指令（`.param`、`.step`、`.meas`、`K` 文など）もすべて回路図に入れ、回路図だけで実行できるようにする
   - 解析が2種類ある場合は、主な方を有効にし、もう一方は `;` で始めてコメントにしておく
2. `scripts/asc_preview.py <asc> <svg>` で SVG を描き、Edge で PNG にして見る
   - 部品・文字の重なりがないか、未接続ピン（赤丸）がないかを確認する
3. LTspice で回路図を開いて実行する
   - LTspice が書き出す `<回路図名>.net` と元の .cir を `scripts/compare_netlists.py` で照合する
   - 「接続は一致」になるまで直す。値や指令の「注意」は内容を見て判断する
4. 回路図の実行結果（`.meas` の値）が .cir の結果と同じことを確かめる

## 8. 波形グラフを作る

同梱の `scripts/plot_waveforms.py` を使う。matplotlib は不要で、SVG を直接書く。

1. raw を SQLite に書き出す（書き出し先は scratchpad）:
   `mcp__ltspice__export_raw_waveforms(path=<.raw>, signals=[...], db_path=<scratchpad>/<名前>.db)`
   - AC 解析では `complex_format="polar"` を付ける。信号名は `"V(out)|mag_db20"` と `"V(out)|phase_deg"` になる
   - 位相は ±180° で折り返した値のまま描かれる。段差が出たら、折り返しであることをレポートに書く
2. グラフを描く（スクリプト冒頭の docstring に全オプションがある）:
   ```bash
   P=~/.claude/skills/ltspice-simulation/scripts/plot_waveforms.py
   # .step の各ステップを重ねる（共通の縦軸で大きさの違いを見せる）
   python $P <db> overlay --signal "V(out)" --labels "Vol 3,Vol 6,Vol 9,Vol 12" --xmin 0.097 --xmax 0.1 \
     --title "出力電圧 V(out) [V]" --out <output>/<Circuit>_Output_<YYYYMMDD>.svg
   # 同じステップの複数信号を重ねる（入力と出力など、同じ単位で大きさが近いもの）
   python $P <db> overlay --signals "V(in),V(out)" --step 0 --labels "入力,出力" ...
   # 信号ごとに縦軸を持つ小さな複数グラフ（各段の波形、ボード線図の利得と位相）
   python $P <db> multiples --signals "V(out)|mag_db20,V(out)|phase_deg" --titles "利得 [dB],位相 [deg]" ...
   ```
   - 時間軸は `--xmin` を 0 とした相対時間 [ms] で表示する。周波数軸は自動で対数になる
   - 2 条件の差（あり − なし など）を描くには、db の `samples` テーブルに SQL で列を足し、その列名を `--signal` に渡す
3. 描いたら目で見る。Edge のヘッドレスモードで PNG にして、Read で確認する（下のコマンドは Windows の Edge の場所。ほかの環境では、SVG を PNG にできるブラウザや変換ツールに置き換える）:
   - `--window-size` は、スクリプトが出力した SVG の大きさ（「出力: … (幅 x 高さ)」）に合わせる
   - `--hide-scrollbars` を付ける
   ```bash
   "/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe" --headless --disable-gpu --hide-scrollbars \
     --screenshot="<scratchpad>/check.png" --window-size=<幅>,<高さ> "file:///<svgの絶対パス>"
   ```
   - ラベルの重なり、はみ出し、軸の範囲を確認する
   - 凡例のラベルは短くする（全角 10 文字程度まで）。凡例の幅はラベルに合わせて広がるが、長すぎると図が横に伸びる

## 9. レポートを書く

[references/report-template.md](references/report-template.md) の構成で書く。
- 読み手は回路に詳しいユーザー本人。用語は回路設計の言葉でよいが、結論は表と短い文で先に示す
- グラフは `![説明](ファイル名.svg)` で埋め込む
- 回路図ファイルは「ファイル」の表に載せる

## 10. 作業ログと報告

**作業ログ:** CLAUDE.md に作業ログの決まりがあれば、それに従う。
- **書き先:** 決まりがなければ、プロジェクトフォルダの `作業ログ.md` に新しいものが上になるよう追記する
- **書く内容:**
  - 決定事項: 仮定したこと（入力のピーク／実効値、採った定数など）を書く
  - 現状・次にやること: 主要な結果の数値と、次に試せることを書く

**ユーザーへの報告:**
- 結論を先に書く。主要な数値の表、目立った挙動、妥当性確認の結果を示す
- 仮定したことのうち、結果を左右するものは「確認してほしい点」として挙げる
- 成果物のパス（回路図は「LTspice で開けばそのまま実行できる」と添える）と、出典のリンクを示す
- ユーザーの GUI でテスト用ファイルを開いた場合は、保存せず閉じてよいと伝える
