"""非反転増幅回路 (G=10) の回路図を asc_builder で作る手本 (OpAmp_NonInv_G10.cir と同じ回路)

使い方: python make_opamp_asc.py <出力する .asc のパス>
"""
import os
import sys

sys.path.insert(0, os.path.expanduser("~/.claude/skills/ltspice-simulation/scripts"))
from asc_builder import Schematic  # noqa: E402

s = Schematic(sheet=(1200, 800))

# ---- OPアンプ ----
u1 = s.place("OpAmps/UniversalOpAmp2", (448, 256), "U1",
             attrs={"Value2": "Avol=200k GBW=3Meg Slew=13Meg",
                    "SpiceLine": "Ilimit=25m Rail=1.5 Vos=0",
                    "SpiceLine2": "Rin=1T"})
s.label(u1["V+"], "vcc", dy=-16)
s.label(u1["V-"], "vee", dy=16)

# ---- 入力 ----
vin = s.place_at("voltage", "+", (192, 272), "VIN", "SINE(0 0.5 1k)")
s.wire(vin["+"], u1["In+"])
s.flag(vin["+"], "in")
s.gnd(vin["-"])

# ---- 帰還: 反転入力の上に RG (左, GND へ) と RF (右, 出力へ) ----
inv = (384, 160)
s.wire(u1["In-"], (inv[0], u1["In-"][1]), inv)
s.flag(inv, "inv")
rg = s.place_at("res", "A", inv, "RG", "1k", rot="R90")       # A が右、B が左
s.wire(rg["B"], (rg["B"][0], 192))
s.gnd((rg["B"][0], 192))
rf = s.place_at("res", "B", inv, "RF", "9k", rot="R90")       # B が左 (inv)、A が右
out = (576, 256)
s.wire(rf["A"], (512, rf["A"][1]), (512, 256))
s.wire(u1["OUT"], out)
s.flag(out, "out")

# ---- 負荷 ----
rl = s.place_at("res", "A", out, "RL", "10k")
s.gnd(rl["B"])

# ---- 電源 ----
vcc = s.place_at("voltage", "+", (720, 192), "VCC", "DC 15")
s.flag(vcc["+"], "vcc")
s.gnd(vcc["-"])
vee = s.place_at("voltage", "+", (848, 192), "VEE", "DC -15")
s.flag(vee["+"], "vee")
s.gnd(vee["-"])

# ---- 指令 ----
y = 432
for d in (".lib UniversalOpAmp2.lib", ".tran 0 5m 0 1u",
          ".meas TRAN vinpp PP V(in) FROM 3m TO 5m",
          ".meas TRAN voutpp PP V(out) FROM 3m TO 5m",
          ".meas TRAN gain PARAM voutpp/vinpp"):
    s.directive((176, y), d)
    y += 32
s.comment((176, 96), "Non-inverting amplifier G=10")
if len(sys.argv) != 2:
    sys.exit("使い方: python make_opamp_asc.py <出力する .asc のパス>")
print(s.save(sys.argv[1]))
