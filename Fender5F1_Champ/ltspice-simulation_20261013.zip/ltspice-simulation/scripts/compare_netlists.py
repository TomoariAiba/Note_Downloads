"""回路図 (.asc) から LTspice が出力したネットリストと、元のネットリスト (.cir) が
同じ回路かどうかを照合する。ネット名が違っていても、接続関係が同じなら一致とみなす。
R・C と、K で結合していない L は、端子の向きが逆でも一致とみなす。

使い方:
  python compare_netlists.py <元の.cir> <回路図から出したネットリスト(.net など)>
  回路図のネットリストは mcp__ltspice__get_schematic_netlist の text をファイルに保存して渡すか、
  LTspice が回路図の実行時に書き出す <回路図名>.net を渡す。

終了コード: 0 = 一致、1 = 不一致あり、2 = 使い方の誤り
"""
import sys

def _utf8_console():
    """Windows のコンソール (cp932) でも日本語が化けないように UTF-8 で出す"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


_utf8_console()


# 素子の種類ごとのノード数 (X と K は別扱い)
NODE_COUNT = {"R": 2, "C": 2, "L": 2, "D": 2, "V": 2, "I": 2, "B": 2,
              "Q": 3, "J": 3, "M": 4, "E": 4, "G": 4, "F": 2, "H": 2,
              "S": 4, "W": 2, "T": 4, "Z": 3}
SKIP_DIRECTIVES = (".end", ".backanno", ".lib", ".include", ".inc")


def decode(raw):
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        text = raw.decode("utf-16")
    else:
        try:
            text = raw.decode("utf-8")       # LTspice 24 以降は UTF-8 で書く
        except UnicodeDecodeError:
            text = raw.decode("latin-1")     # 古い形式 (Windows-1252)
    return text.replace("µ", "u").replace("§", "")   # µ は u、§ は回路図由来の印


def read_lines(path):
    """継続行 (+) をつなぎ、コメントを除いた行のリストを返す"""
    try:
        with open(path, "rb") as f:
            text = decode(f.read())
    except OSError as e:
        sys.exit(f"エラー: ファイルを開けません: {path} ({e})")
    out = []
    for line in text.replace("\r", "").split("\n"):
        line = line.split(";")[0].rstrip()
        if not line.strip() or line.lstrip().startswith("*"):
            continue
        if line.lstrip().startswith("+") and out:
            out[-1] += " " + line.lstrip()[1:]
        else:
            out.append(line.strip())
    return out


def parse(path):
    """{素子名: (ノードのリスト, 値の文字列)} と、指令の集合を返す"""
    elems, directives = {}, set()
    for line in read_lines(path):
        tok = line.split()
        head = tok[0].upper()
        if head.startswith("."):
            d = " ".join(tok).lower()
            if d.split()[0] not in SKIP_DIRECTIVES:
                directives.add(d)
            continue
        kind = head[0]
        if kind == "K":
            elems[head] = ([], " ".join(t.upper() for t in tok[1:]))
            continue
        if kind == "X":
            body = [t for t in tok[1:] if "=" not in t and t.lower() != "params:"]
            params = " ".join(t for t in tok[1:] if "=" in t)
            nodes, value = body[:-1], (body[-1] + " " + params) if body else params
        else:
            n = NODE_COUNT.get(kind)
            if n is None:
                print(f"注意: 未対応の素子 {tok[0]} は照合しません")
                continue
            nodes, value = tok[1:1 + n], " ".join(tok[1 + n:])
        elems[head] = ([x.lower() for x in nodes], value.lower().strip())
    return elems, directives


class NetMap:
    """.cir のネット ⇔ 回路図のネット の一対一対応"""

    def __init__(self):
        self.fwd, self.back = {"0": "0"}, {"0": "0"}

    def conflicts(self, na, nb):
        return [(x, y) for x, y in zip(na, nb)
                if (x in self.fwd and self.fwd[x] != y) or (y in self.back and self.back[y] != x)]

    def known(self, na, nb):
        return any(x in self.fwd for x in na) or any(y in self.back for y in nb)

    def bind(self, na, nb):
        for x, y in zip(na, nb):
            self.fwd.setdefault(x, y)
            self.back.setdefault(y, x)


def compare(cir_path, sch_path):
    a, da = parse(cir_path)
    b, db = parse(sch_path)
    problems, warnings = [], []
    for name in sorted(set(a) - set(b)):
        problems.append(f"回路図に無い素子: {name}")
    for name in sorted(set(b) - set(a)):
        problems.append(f"元の .cir に無い素子: {name}")

    coupled = {t for (nodes, v) in a.values() if not nodes for t in v.split()}  # K 文の L
    nets = NetMap()
    pending = []
    for name in sorted(set(a) & set(b)):
        (na, va), (nb, vb) = a[name], b[name]
        if va.replace(" ", "") != vb.replace(" ", ""):
            warnings.append(f"{name}: 値が違います (.cir: {va} / 回路図: {vb})")
        if len(na) != len(nb):
            problems.append(f"{name}: ノード数が違います ({na} / {nb})")
            continue
        if len(na) == 2 and (name[0] in "RC" or (name[0] == "L" and name not in coupled)):
            pending.append(name)    # 向きは後で決める
            continue
        for x, y in nets.conflicts(na, nb):
            problems.append(f"{name}: .cir のネット {x} が回路図では {y} です"
                            f" (他の素子からは {nets.fwd.get(x, '-')} / {nets.back.get(y, '-')} と判定)")
        nets.bind(na, nb)

    # 向きが決まらない 2 端子素子は、対応が分かっているネットにつながるものから順に決める
    changed = True
    while pending and changed:
        changed = False
        for name in list(pending):
            na, nb = a[name][0], b[name][0]
            options = [o for o in (nb, nb[::-1]) if not nets.conflicts(na, o)]
            if not options:
                problems.append(f"{name}: .cir では {na} 間、回路図では {nb} 間につながっています"
                                f" (回路図側は .cir の {[nets.back.get(y, '?') for y in nb]} に相当)")
            elif not (nets.known(na, nb) or len(options) == 1):
                continue
            else:
                nets.bind(na, options[0])
            pending.remove(name)
            changed = True
    for name in pending:
        nets.bind(a[name][0], b[name][0])

    for d in sorted(da - db):
        warnings.append(f"回路図に無い指令: {d}")
    for d in sorted(db - da):
        warnings.append(f"元の .cir に無い指令: {d}")
    return problems, warnings, len(set(a) & set(b))


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(2)
    problems, warnings, n = compare(sys.argv[1], sys.argv[2])
    for w in warnings:
        print("注意:", w)
    for p in problems:
        print("不一致:", p)
    if problems:
        print(f"結果: 不一致 {len(problems)} 件")
        sys.exit(1)
    print(f"結果: 接続は一致 (素子 {n} 個)" + (f"、注意 {len(warnings)} 件" if warnings else ""))


if __name__ == "__main__":
    main()
