"""LTspice 回路図 (.asc) を Python で組み立てるための小さなライブラリ。

ピン座標は LTspice のシンボル定義 (.asy) から読み取り、回転・反転を計算して求める。
「このピンをこの点に置く」と指定できるので、座標の手計算による接続ミスが起きない。

使い方 (make_<回路名>_asc.py の中で):
    import os, sys; sys.path.insert(0, os.path.expanduser("~/.claude/skills/ltspice-simulation/scripts"))
    from asc_builder import Schematic
    s = Schematic()
    vin = s.place_at("voltage", "+", (0, 0), "Vin", "SINE(0 1 1k)")      # + ピンを (0,0) に置く
    r1 = s.place_at("res", "A", (160, 0), "R1", "10k", rot="R90")          # 横置き抵抗
    s.wire(vin["+"], r1["A"])                                              # ピン同士を配線
    s.gnd(vin["-"])                                                        # ピンに GND 記号
    s.label(r1["B"], "out", dx=32)                                         # 引き出し線 + ネットラベル
    s.directive((0, 200), ".tran 5m")
    s.save("Circuit_20261003.asc")

座標系: x は右、y は下が正。部品とピンは 16 の倍数に置く (LTspice のグリッド)。
"""
import os
import pathlib
import re
import sys


def _utf8_console():
    """Windows のコンソール (cp932) でも日本語が化けないように UTF-8 で出す"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


_utf8_console()

GRID = 16
# シンボルを探すフォルダ (先にあるものが優先)
# 先頭は実行したフォルダ。LTspice も回路図と同じフォルダの .asy を使うので、作業フォルダで実行する
SYMBOL_DIRS = [
    pathlib.Path.cwd(),
    pathlib.Path(os.environ.get("LOCALAPPDATA", "")) / "LTspice" / "lib" / "sym",
    pathlib.Path.home() / "OneDrive" / "ドキュメント" / "LTspice",
    pathlib.Path.home() / "Documents" / "LTspice",
]
# 回転したときに部品名・値が重ならない表示位置 (LTspice が GUI で付ける値と同じ)
DEFAULT_WINDOWS = {
    ("res", "R90"): ["WINDOW 0 0 56 VBottom 2", "WINDOW 3 32 56 VTop 2"],
    ("res", "R270"): ["WINDOW 0 32 56 VTop 2", "WINDOW 3 0 56 VBottom 2"],
    ("cap", "R90"): ["WINDOW 0 0 32 VBottom 2", "WINDOW 3 32 32 VTop 2"],
    ("cap", "R270"): ["WINDOW 0 32 32 VTop 2", "WINDOW 3 0 32 VBottom 2"],
    ("ind", "R90"): ["WINDOW 0 5 56 VBottom 2", "WINDOW 3 32 56 VTop 2"],
    ("ind", "R270"): ["WINDOW 0 32 56 VTop 2", "WINDOW 3 5 56 VBottom 2"],
}
ROTATIONS = ("R0", "R90", "R180", "R270", "M0", "M90", "M180", "M270")


class SchematicError(Exception):
    pass


def transform(px, py, rot):
    """シンボル座標 (px, py) を回転・反転したオフセットを返す (LTspice の定義どおり)"""
    if rot not in ROTATIONS:
        raise SchematicError(f"回転の指定が不正です: {rot}")
    if rot.startswith("M"):
        px = -px
    turn = int(rot[1:])
    return {0: (px, py), 90: (-py, px), 180: (-px, -py), 270: (py, -px)}[turn]


def find_symbol(name):
    """シンボル名 ("res", "OpAmps/UniversalOpAmp2" など) から .asy のパスを探す"""
    rel = pathlib.Path(*re.split(r"[\\/]+", name)).with_suffix(".asy")
    for base in SYMBOL_DIRS:
        p = base / rel
        if p.exists():
            return p
        # 大文字小文字の違いを許す
        if base.exists() and len(rel.parts) == 1:
            for q in base.rglob("*.asy"):
                if q.name.lower() == rel.name.lower():
                    return q
    raise SchematicError(f"シンボルが見つかりません: {name} (探した場所: {', '.join(map(str, SYMBOL_DIRS))})")


def read_prefix(path):
    """.asy の SYMATTR Prefix を返す (無ければ空文字)"""
    for line in path.read_text(encoding="latin-1").splitlines():
        t = line.split()
        if len(t) >= 3 and t[0] == "SYMATTR" and t[1] == "Prefix":
            return t[2]
    return ""


def read_pins(path):
    """.asy から [(pin名, x, y, spiceorder)] を読む"""
    pins, cur = [], None
    for line in path.read_text(encoding="latin-1").splitlines():
        t = line.split()
        if not t:
            continue
        if t[0] == "PIN":
            cur = {"x": int(t[1]), "y": int(t[2]), "name": None, "order": None}
            pins.append(cur)
        elif t[0] == "PINATTR" and cur is not None:
            if t[1] == "PinName":
                cur["name"] = " ".join(t[2:])
            elif t[1] == "SpiceOrder":
                cur["order"] = int(t[2])
    if not pins:
        raise SchematicError(f"ピン定義がありません: {path}")
    return pins


class Part:
    """配置した部品。part["A"] や part[1] (SpiceOrder) でピンの絶対座標を返す"""

    def __init__(self, inst, symbol, origin, rot, pins):
        self.inst, self.symbol, self.origin, self.rot = inst, symbol, origin, rot
        self._by_name, self._by_order = {}, {}
        for p in pins:
            dx, dy = transform(p["x"], p["y"], rot)
            pt = (origin[0] + dx, origin[1] + dy)
            if p["name"] is not None:
                self._by_name[p["name"]] = pt
            if p["order"] is not None:
                self._by_order[p["order"]] = pt

    def __getitem__(self, key):
        table = self._by_order if isinstance(key, int) else self._by_name
        if key not in table:
            raise SchematicError(f"{self.inst} ({self.symbol}) にピン {key} はありません。"
                                 f" ピン: {list(self._by_name)}")
        return table[key]

    def pins(self):
        return dict(self._by_name)


class Schematic:
    def __init__(self, sheet=(2400, 1600)):
        self.sheet = sheet
        self.lines, self.parts = [], []
        self._pin_cache = {}
        self._prefix_cache = {}

    # ---------- 部品 ----------
    def _pins(self, symbol):
        if symbol not in self._pin_cache:
            self._pin_cache[symbol] = read_pins(find_symbol(symbol))
        return self._pin_cache[symbol]

    def _prefix(self, symbol):
        if symbol not in self._prefix_cache:
            self._prefix_cache[symbol] = read_prefix(find_symbol(symbol))
        return self._prefix_cache[symbol]

    def place(self, symbol, origin, inst, value=None, rot="R0", attrs=None, windows=None):
        """シンボル原点を origin に置く。attrs は {"SpiceLine": "...", "Value2": "..."} など
        Prefix が X のシンボル (真空管・OPアンプ) は、LTspice が部品名の前に必ず X を付ける。
        .cir の XV1A に合わせたいときは部品名を V1A にする (X で始まる名前は X を自動で外す)"""
        self._check_grid(origin, f"{inst} の原点")
        if self._prefix(symbol).upper() == "X" and inst.upper().startswith("X") and len(inst) > 1:
            print(f"注意: {inst} → {inst[1:]} に変更しました (Prefix X のシンボルは LTspice が X を付けるため)")
            inst = inst[1:]
        part = Part(inst, symbol, origin, rot, self._pins(symbol))
        sym_text = symbol.replace("/", "\\").replace("\\", "\\\\")
        out = [f"SYMBOL {sym_text} {origin[0]} {origin[1]} {rot}"]
        base = re.split(r"[\\/]+", symbol)[-1].lower()
        out += windows if windows is not None else DEFAULT_WINDOWS.get((base, rot), [])
        out.append(f"SYMATTR InstName {inst}")
        if value is not None:
            out.append(f"SYMATTR Value {value}")
        for k, v in (attrs or {}).items():
            out.append(f"SYMATTR {k} {v}")
        self.lines.append("\n".join(out))
        self.parts.append(part)
        return part

    def place_at(self, symbol, pin, at, inst, value=None, rot="R0", attrs=None, windows=None):
        """指定したピンが点 at に来るように置く (配線の終点に部品をつなぐときに使う)"""
        p = next((q for q in self._pins(symbol) if q["name"] == pin or q["order"] == pin), None)
        if p is None:
            raise SchematicError(f"{symbol} にピン {pin} はありません")
        dx, dy = transform(p["x"], p["y"], rot)
        return self.place(symbol, (at[0] - dx, at[1] - dy), inst, value, rot, attrs, windows)

    # ---------- 配線・ラベル ----------
    def wire(self, *pts):
        """点を順に結ぶ。斜めになる区間は、横 → 縦の順に直角に曲げる"""
        for a, b in zip(pts, pts[1:]):
            if a[0] != b[0] and a[1] != b[1]:
                corner = (b[0], a[1])
                self._seg(a, corner)
                self._seg(corner, b)
            else:
                self._seg(a, b)

    def wire_v(self, a, b):
        """縦 → 横の順に曲げて結ぶ"""
        corner = (a[0], b[1])
        self._seg(a, corner)
        self._seg(corner, b)

    def _seg(self, a, b):
        if a != b:
            self.lines.append(f"WIRE {a[0]} {a[1]} {b[0]} {b[1]}")

    def flag(self, pt, net):
        """点 pt にネット名を付ける (配線の端点かピンの位置であること)"""
        self.lines.append(f"FLAG {pt[0]} {pt[1]} {net}")

    def gnd(self, pt):
        self.flag(pt, "0")

    def label(self, pt, net, dx=0, dy=0):
        """pt から (dx, dy) だけ引き出し線を出し、その先にネットラベルを付ける。
        遠い場所どうし (B+、帰還、電源レール) をつなぐときに使う。同じ名前のラベルは電気的につながる"""
        end = (pt[0] + dx, pt[1] + dy)
        self.wire(pt, end)
        self.flag(end, net)
        return end

    # ---------- テキスト ----------
    def directive(self, pt, text):
        """SPICE 指令 (.tran など)。複数行は \\n で区切る"""
        one_line = text.replace("\n", "\\n")  # .asc では改行を文字列 \n で表す
        self.lines.append(f"TEXT {pt[0]} {pt[1]} Left 2 !{one_line}")

    def comment(self, pt, text, size=2):
        self.lines.append(f"TEXT {pt[0]} {pt[1]} Left {size} ;{text}")

    # ---------- 出力 ----------
    def _check_grid(self, pt, what):
        if pt[0] % GRID or pt[1] % GRID:
            raise SchematicError(f"{what} {pt} が {GRID} の倍数ではありません")

    def save(self, path):
        # LTspice が書くのと同じ順 (WIRE → FLAG → SYMBOL → TEXT) に並べる
        order = {"WIRE": 0, "FLAG": 1, "SYMBOL": 2, "TEXT": 3}
        ordered = sorted(self.lines, key=lambda t: order.get(t.split(" ", 1)[0], 4))
        body = f"Version 4\nSHEET 1 {self.sheet[0]} {self.sheet[1]}\n" + "\n".join(ordered) + "\n"
        try:
            data = body.encode("ascii")
        except UnicodeEncodeError as e:
            raise SchematicError(f".asc に ASCII 以外の文字があります (µ は u と書く): {e}") from e
        pathlib.Path(path).write_bytes(data)
        return path
