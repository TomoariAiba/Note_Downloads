"""LTspice の波形データ (export_raw_waveforms で書き出した SQLite) から SVG グラフを作る。
matplotlib が無い環境でも動くよう、SVG を直接書く。

使い方:
  # 1 つの信号を .step の各ステップで重ねる (共通の縦軸)
  python plot_waveforms.py <db> overlay --signal "V(out)" [--steps 0,1,2] [--labels "A,B,C"]
         [--xmin X] [--xmax X] [--title T] --out out.svg
  # 複数の信号を 1 ステップで重ねる (同じ単位で大きさが近い信号どうし)
  python plot_waveforms.py <db> overlay --signals "V(in),V(out)" [--step 0] [--labels "入力,出力"] ...
  # 複数の信号を 1 ステップで並べる (信号ごとに縦軸を持つ小さな複数グラフ)
  python plot_waveforms.py <db> multiples --signals "V(in),V(out)" [--titles "入力,出力"]
         [--step 0] [--xmin X] [--xmax X] [--title T] --out out.svg
  # ボード線図: export_raw_waveforms(complex_format="polar") の db で、利得と位相を並べる
  python plot_waveforms.py <db> multiples --signals "V(out)|mag_db20,V(out)|phase_deg" \
         --titles "利得 [dB],位相 [deg]" --out bode.svg
  # 2 条件の差 (例: あり − なし) を描くときは、db の samples テーブルに SQL で列を足してから
  # その列名を --signal に渡す

横軸は db の run テーブルの x_name を使う。time は ms 表示 (--xmin を 0 とした相対時間)、frequency は対数軸。
--xmin/--xmax は db に入っている値の単位 (秒 / Hz) で指定する。
"""
import argparse
import math
import re
import sqlite3
import sys

def _utf8_console():
    """Windows のコンソール (cp932) でも日本語が化けないように UTF-8 で出す"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


_utf8_console()


# 既定パレットの categorical 色 (固定順。系列は 8 本まで)
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
FONT = "font-family='Segoe UI, Meiryo, sans-serif'"
MAX_POINTS = 4000          # 1 本あたりの描画点数の上限 (SVG を重くしないため間引く)
PANEL_W, PANEL_H = 330, 150
OVERLAY_W, OVERLAY_H = 620, 320


def fail(msg):
    sys.exit(f"エラー: {msg}")


def text_width(text, size=12):
    """文字列の表示幅の目安 (全角は約 1 文字分、半角は約 0.6 文字分)"""
    return sum(size if ord(c) > 0x2000 else size * 0.6 for c in text)


def esc(text):
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ---------------- データ読み込み ----------------
def x_axis_info(conn):
    row = conn.execute("SELECT x_name FROM run").fetchone()
    if not row:
        fail("run テーブルがありません (export_raw_waveforms の出力か確認してください)")
    x_name = row[0]
    if x_name == "time":
        return x_name, 1e3, "時間 [ms]", False
    if x_name == "frequency":
        return x_name, 1.0, "周波数 [Hz]", True
    return x_name, 1.0, x_name, False


def columns(conn):
    return [r[1] for r in conn.execute("PRAGMA table_info(samples)")]


def load(conn, x_name, step, signal, xmin, xmax):
    if signal not in columns(conn):
        fail(f"信号 {signal} が db にありません。候補: {', '.join(columns(conn)[3:])}")
    sql = f'SELECT "{x_name}", "{signal}" FROM samples WHERE step=?'
    args = [step]
    if xmin is not None:
        sql += f' AND "{x_name}" >= ?'
        args.append(xmin)
    if xmax is not None:
        sql += f' AND "{x_name}" <= ?'
        args.append(xmax)
    rows = [r for r in conn.execute(sql + " ORDER BY point", args) if r[1] is not None]
    if not rows:
        fail(f"データがありません (step={step}, signal={signal}, 範囲={xmin}〜{xmax})")
    stride = max(1, len(rows) // MAX_POINTS)
    rows = rows[::stride]
    return [r[0] for r in rows], [r[1] for r in rows]


def x0(a, x_name):
    """時間軸は --xmin を 0 とした相対時間で表示する (周波数軸はそのまま)"""
    return a.xmin if (x_name == "time" and a.xmin is not None) else 0.0


# ---------------- 目盛り ----------------
def nice_ticks(lo, hi, n=5):
    """1/2/5 系列で目盛りを決める"""
    span = (hi - lo) or abs(hi) or 1.0
    raw = span / n
    mag = 10 ** math.floor(math.log10(raw))
    step = next(m * mag for m in (1, 2, 5, 10) if m * mag >= raw)
    ticks, v = [], math.ceil(lo / step - 1e-9) * step
    while v <= hi + step * 1e-6:
        ticks.append(round(v, 12))
        v += step
    return ticks


def log_ticks(lo, hi):
    return [10 ** e for e in range(math.ceil(math.log10(lo)), math.floor(math.log10(hi)) + 1)]


def fmt(v):
    if abs(v) >= 1e6:
        return f"{v / 1e6:g}M"
    if abs(v) >= 1e3:
        return f"{v / 1e3:g}k"
    return f"{v:g}"


# ---------------- 描画 ----------------
class Panel:
    def __init__(self, x, y, w, h, xr, yr, title, logx):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.xlo, self.xhi = xr
        self.ylo, self.yhi = yr
        self.title, self.logx = title, logx

    def tx(self, v):
        return math.log10(v) if self.logx else v

    def px(self, v):
        return self.x + (self.tx(v) - self.tx(self.xlo)) / ((self.tx(self.xhi) - self.tx(self.xlo)) or 1) * self.w

    def py(self, v):
        return self.y + self.h - (v - self.ylo) / ((self.yhi - self.ylo) or 1) * self.h

    def axes(self):
        s = [f"<text x='{self.x}' y='{self.y - 10}' {FONT} font-size='13' fill='{INK}' font-weight='600'>{esc(self.title)}</text>"]
        for v in nice_ticks(self.ylo, self.yhi):
            if not self.ylo <= v <= self.yhi:
                continue
            y = self.py(v)
            s.append(f"<line x1='{self.x}' x2='{self.x + self.w}' y1='{y:.1f}' y2='{y:.1f}' stroke='{GRID}'/>")
            s.append(f"<text x='{self.x - 6}' y='{y + 4:.1f}' {FONT} font-size='11' fill='{INK2}' text-anchor='end'>{fmt(v)}</text>")
        xt = log_ticks(self.xlo, self.xhi) if self.logx else nice_ticks(self.xlo, self.xhi, 6)
        for v in xt:
            if not self.xlo <= v <= self.xhi:
                continue
            x = self.px(v)
            if self.logx:
                s.append(f"<line x1='{x:.1f}' x2='{x:.1f}' y1='{self.y}' y2='{self.y + self.h}' stroke='{GRID}'/>")
            s.append(f"<line x1='{x:.1f}' x2='{x:.1f}' y1='{self.y + self.h}' y2='{self.y + self.h + 4}' stroke='{INK2}'/>")
            s.append(f"<text x='{x:.1f}' y='{self.y + self.h + 17}' {FONT} font-size='11' fill='{INK2}' text-anchor='middle'>{fmt(v)}</text>")
        s.append(f"<line x1='{self.x}' x2='{self.x + self.w}' y1='{self.y + self.h}' y2='{self.y + self.h}' stroke='{INK2}'/>")
        return s

    def line(self, xs, ys, color):
        pts = " ".join(f"{self.px(a):.1f},{self.py(b):.1f}" for a, b in zip(xs, ys))
        return f"<polyline points='{pts}' fill='none' stroke='{color}' stroke-width='2' stroke-linejoin='round'/>"


def padded(vals_list, symmetric=False):
    lo = min(min(v) for v in vals_list)
    hi = max(max(v) for v in vals_list)
    if symmetric and lo < 0 < hi:
        m = max(-lo, hi) * 1.08
        return -m, m
    pad = (hi - lo) * 0.08 or abs(hi) * 0.1 or 0.1
    return lo - pad, hi + pad


def svg_doc(w, h, body):
    return (f"<svg xmlns='http://www.w3.org/2000/svg' width='{w}' height='{h}' viewBox='0 0 {w} {h}'>"
            f"<rect width='100%' height='100%' fill='{SURFACE}'/>" + "".join(body) + "</svg>")


def overlay(conn, a):
    x_name, xscale, xlabel, logx = x_axis_info(conn)
    if a.signals:   # 複数の信号を 1 ステップで重ねる
        series = [(a.step, sig.strip()) for sig in a.signals.split(",")]
        default_labels = [sig for _, sig in series]
    else:           # 1 つの信号を .step の各ステップで重ねる
        steps = [int(s) for s in a.steps.split(",")] if a.steps else \
            [r[0] for r in conn.execute("SELECT step FROM steps ORDER BY step")]
        series = [(s, a.signal) for s in steps]
        default_labels = [f"step {s}" for s in steps]
    if len(series) > len(SERIES):
        fail(f"系列は {len(SERIES)} 本までにしてください (指定 {len(series)} 本)")
    labels = a.labels.split(",") if a.labels else default_labels
    if len(labels) != len(series):
        fail("--labels の数が系列の数と合いません")
    data = []
    for step, sig in series:
        xs, ys = load(conn, x_name, step, sig, a.xmin, a.xmax)
        data.append(([(v - x0(a, x_name)) * xscale for v in xs], ys))
    lo = 0.0 if (x_name == "time" and a.xmin is not None) else min(d[0][0] for d in data)
    xr = (lo, max(d[0][-1] for d in data))
    # 時間波形は 0 を中心に上下対称、dB や位相はデータの範囲に合わせる
    p = Panel(70, 60, OVERLAY_W, OVERLAY_H, xr,
              padded([d[1] for d in data], symmetric=(x_name == "time")),
              a.title or a.signal or a.signals, logx)
    body = p.axes()
    body.append(f"<text x='{p.x + p.w / 2}' y='{p.y + p.h + 38}' {FONT} font-size='12' fill='{INK2}' text-anchor='middle'>{xlabel}</text>")
    for (xs, ys), color in zip(data, SERIES):
        body.append(p.line(xs, ys, color))
    if len(series) > 1:  # 2 系列以上なら凡例を付ける
        for i, (lab, color) in enumerate(zip(labels, SERIES)):
            y = p.y + 20 + i * 24
            body.append(f"<line x1='{p.x + p.w + 20}' x2='{p.x + p.w + 44}' y1='{y}' y2='{y}' stroke='{color}' stroke-width='3' stroke-linecap='round'/>")
            body.append(f"<text x='{p.x + p.w + 50}' y='{y + 4}' {FONT} font-size='12' fill='{INK}'>{esc(lab)}</text>")
    legend_w = 70 + max(text_width(lab) for lab in labels) if len(series) > 1 else 40
    return svg_doc(int(OVERLAY_W + 70 + legend_w + 20), OVERLAY_H + 120, body)


def multiples(conn, a):
    x_name, xscale, xlabel, logx = x_axis_info(conn)
    signals = a.signals.split(",")
    titles = a.titles.split(",") if a.titles else signals
    if len(titles) != len(signals):
        fail("--titles の数が --signals の数と合いません")
    rows = math.ceil(len(signals) / 2)
    body = []
    for i, (sig, title) in enumerate(zip(signals, titles)):
        xs, ys = load(conn, x_name, a.step, sig.strip(), a.xmin, a.xmax)
        xs = [(v - x0(a, x_name)) * xscale for v in xs]
        lo = 0.0 if (x_name == "time" and a.xmin is not None) else xs[0]
        p = Panel(70 + (i % 2) * 420, 50 + (i // 2) * 210, PANEL_W, PANEL_H,
                  (lo, xs[-1]), padded([ys]), title.strip(), logx)
        body += p.axes()
        body.append(p.line(xs, ys, SERIES[0]))
    h = 50 + rows * 210 + 30
    caption = f"{xlabel}" + (f" ― {a.title}" if a.title else "")
    body.append(f"<text x='445' y='{h - 15}' {FONT} font-size='12' fill='{INK2}' text-anchor='middle'>{esc(caption)}</text>")
    return svg_doc(880, h, body)


def main():
    ap = argparse.ArgumentParser(description="LTspice 波形 db から SVG を作る")
    ap.add_argument("db")
    ap.add_argument("mode", choices=["overlay", "multiples"])
    ap.add_argument("--signal")
    ap.add_argument("--signals")
    ap.add_argument("--steps")
    ap.add_argument("--step", type=int, default=0)
    ap.add_argument("--labels")
    ap.add_argument("--titles")
    ap.add_argument("--title")
    ap.add_argument("--xmin", type=float)
    ap.add_argument("--xmax", type=float)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    try:
        conn = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    except sqlite3.Error as e:
        fail(f"db を開けません: {a.db} ({e})")
    if a.mode == "overlay" and not (a.signal or a.signals):
        fail("overlay には --signal (ステップを重ねる) か --signals (信号を重ねる) が必要です")
    if a.mode == "multiples" and not a.signals:
        fail("multiples には --signals が必要です")
    svg = overlay(conn, a) if a.mode == "overlay" else multiples(conn, a)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(svg)
    size = re.search(r"width='(\d+)' height='(\d+)'", svg)
    print(f"出力: {a.out} ({size.group(1)} x {size.group(2)}。確認のスクリーンショットはこの大きさで撮る)")


if __name__ == "__main__":
    main()
