"""LTspice 回路図 (.asc) を SVG に描いて、配置の見栄えと未接続ピンを確認する。
LTspice の画面と完全に同じではない (文字揃え・縦書きは近似。回転した部品の文字の向きは
LTspice と異なることがある) が、部品の重なり、
ラベルのはみ出し、つながっていないピンを見つけるには十分。

使い方:
  python asc_preview.py <回路図.asc> <出力.svg>
  → 未接続ピンは赤丸で示し、一覧を標準出力に出す。PNG で見るときは Edge のヘッドレスで撮る。
"""
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from asc_builder import find_symbol, transform, SchematicError  # noqa: E402


def _utf8_console():
    """Windows のコンソール (cp932) でも日本語が化けないように UTF-8 で出す"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


_utf8_console()

INK, WIRE_C, SYM_C, NET_C, TEXT_C, BAD = "#222", "#1c5cab", "#6b3d00", "#008300", "#52514e", "#e34948"
MARGIN = 64
CHAR_W = 9          # プレビュー上の 1 文字の幅 (フォントサイズ 13 相当)


def esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def text_svg(x, y, txt, just):
    """LTspice の文字揃え (Left/Right/Center/Top/Bottom、先頭 V は縦書き) を近似して描く"""
    vertical = just.startswith("V")
    base = just[1:] if vertical else just
    anchor = {"Left": "start", "Right": "end"}.get(base, "middle")
    # LTspice は揃えの基準点から少し離して文字を描くので、その分ずらす
    pad = {"Left": 8, "Right": -8}.get(base, 0)
    if vertical:
        y -= pad
    else:
        x += pad
    dy = {"Top": 12, "Bottom": -4}.get(base, 4)
    rot = f" transform='rotate(-90 {x} {y})'" if vertical else ""
    return (f"<text x='{x}' y='{y + dy}' text-anchor='{anchor}' font-size='13' fill='{INK}' "
            f"font-family='Consolas, monospace'{rot}>{esc(txt)}</text>")


def read_asy(name):
    """シンボルの図形・ピン・既定の表示位置を読む"""
    path = find_symbol(name.replace("\\\\", "/").replace("\\", "/"))
    shapes, pins, windows, attrs = [], [], {}, {}
    for line in path.read_text(encoding="latin-1").splitlines():
        t = line.split()
        if not t:
            continue
        if t[0] in ("LINE", "RECTANGLE", "CIRCLE", "ARC"):
            shapes.append((t[0], [int(v) for v in t[2:]]))
        elif t[0] == "PIN":
            pins.append((int(t[1]), int(t[2])))
        elif t[0] == "WINDOW":
            windows[int(t[1])] = (int(t[2]), int(t[3]), t[4] if len(t) > 4 else "Left")
        elif t[0] == "SYMATTR" and len(t) >= 3:
            attrs[t[1]] = " ".join(t[2:])
    return shapes, pins, windows, attrs


def parse_asc(path):
    wires, flags, symbols, texts = [], [], [], []
    raw = pathlib.Path(path).read_bytes()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    cur = None
    for line in text.splitlines():
        t = line.split()
        if not t:
            continue
        if t[0] == "WIRE":
            wires.append(tuple(int(v) for v in t[1:5]))
        elif t[0] == "FLAG":
            flags.append((int(t[1]), int(t[2]), " ".join(t[3:])))
        elif t[0] == "SYMBOL":
            cur = {"name": t[1], "x": int(t[2]), "y": int(t[3]), "rot": t[4], "attrs": {}, "windows": {}}
            symbols.append(cur)
        elif t[0] == "SYMATTR" and cur is not None:
            cur["attrs"][t[1]] = " ".join(t[2:])
        elif t[0] == "WINDOW" and cur is not None:
            cur["windows"][int(t[1])] = (int(t[2]), int(t[3]), t[4] if len(t) > 4 else "Left")
        elif t[0] == "TEXT":
            m = re.match(r"TEXT (-?\d+) (-?\d+) \S+ \d+ (.*)", line)
            if m:
                texts.append((int(m.group(1)), int(m.group(2)), m.group(3)))
    return wires, flags, symbols, texts


def render(asc, out):
    wires, flags, symbols, texts = parse_asc(asc)
    body, xs, ys = [], [], []
    endpoints = {}
    for x1, y1, x2, y2 in wires:
        body.append(f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='{WIRE_C}' stroke-width='2'/>")
        for p in ((x1, y1), (x2, y2)):
            endpoints[p] = endpoints.get(p, 0) + 1
        xs += [x1, x2]
        ys += [y1, y2]

    pin_points = []
    for s in symbols:
        try:
            shapes, pins, windows, defattrs = read_asy(s["name"])
        except SchematicError as e:
            print("注意:", e)
            continue
        ox, oy, rot = s["x"], s["y"], s["rot"]

        def tp(px, py):
            dx, dy = transform(px, py, rot)
            return ox + dx, oy + dy

        for kind, v in shapes:
            if kind == "LINE":
                (a, b), (c, d) = tp(v[0], v[1]), tp(v[2], v[3])
                body.append(f"<line x1='{a}' y1='{b}' x2='{c}' y2='{d}' stroke='{SYM_C}' stroke-width='1.5'/>")
            elif kind in ("RECTANGLE", "CIRCLE"):
                (a, b), (c, d) = tp(v[0], v[1]), tp(v[2], v[3])
                x0, x1, y0, y1 = min(a, c), max(a, c), min(b, d), max(b, d)
                if kind == "RECTANGLE":
                    body.append(f"<rect x='{x0}' y='{y0}' width='{x1 - x0}' height='{y1 - y0}' fill='none' stroke='{SYM_C}' stroke-width='1.5'/>")
                else:
                    body.append(f"<ellipse cx='{(x0 + x1) / 2}' cy='{(y0 + y1) / 2}' rx='{(x1 - x0) / 2}' ry='{(y1 - y0) / 2}' fill='none' stroke='{SYM_C}' stroke-width='1.5'/>")
            elif kind == "ARC" and len(v) >= 8:
                (a, b), (c, d) = tp(v[0], v[1]), tp(v[2], v[3])
                (sx, sy), (ex, ey) = tp(v[4], v[5]), tp(v[6], v[7])
                rx, ry = abs(c - a) / 2, abs(d - b) / 2
                sweep = 1 if rot.startswith("M") else 0   # LTspice の円弧は始点から反時計回り
                body.append(f"<path d='M{sx},{sy} A{rx},{ry} 0 0 {sweep} {ex},{ey}' fill='none' stroke='{SYM_C}' stroke-width='1.5'/>")
        for px, py in pins:
            pin_points.append(tp(px, py))
        xs.append(ox)
        ys.append(oy)
        # 部品名 (WINDOW 0) と値 (WINDOW 3)
        win = dict(windows)
        win.update(s["windows"])
        labels = {0: s["attrs"].get("InstName", ""),
                  3: s["attrs"].get("Value", defattrs.get("Value", ""))}
        for wid, txt in labels.items():
            if txt and wid in win:
                wx, wy, just = win[wid]
                tx, ty = tp(wx, wy)
                body.append(text_svg(tx, ty, txt, just))
                xs += [tx - len(txt) * CHAR_W, tx + len(txt) * CHAR_W]
                ys += [ty - len(txt) * CHAR_W, ty + len(txt) * CHAR_W]

    for x, y, net in flags:
        if net == "0":
            body.append(f"<path d='M{x - 12},{y} H{x + 12} M{x - 7},{y + 5} H{x + 7} M{x - 3},{y + 10} H{x + 3}' stroke='{INK}' stroke-width='1.5'/>")
        else:
            body.append(f"<text x='{x + 4}' y='{y - 4}' font-size='13' fill='{NET_C}' font-family='Consolas, monospace'>{esc(net)}</text>")
            xs.append(x + len(net) * CHAR_W)
        xs.append(x)
        ys.append(y)
    for x, y, txt in texts:
        color = "#1c5cab" if txt.startswith("!") else TEXT_C
        for i, part in enumerate(txt[1:].split("\\n")):
            body.append(f"<text x='{x}' y='{y + 4 + i * 16}' font-size='13' fill='{color}' font-family='Consolas, monospace'>{esc(part)}</text>")
            xs += [x, x + len(part) * CHAR_W]
            ys.append(y + i * 16)

    # 接続点 (3 本以上の配線) と未接続ピン
    for p, n in endpoints.items():
        if n >= 3:
            body.append(f"<circle cx='{p[0]}' cy='{p[1]}' r='4' fill='{WIRE_C}'/>")
    flag_points = {(x, y) for x, y, _ in flags}
    pin_count = {}
    for p in pin_points:
        pin_count[p] = pin_count.get(p, 0) + 1
    unconnected = [p for p in pin_points
                   if p not in endpoints and p not in flag_points and pin_count[p] < 2]
    for p in unconnected:
        body.append(f"<circle cx='{p[0]}' cy='{p[1]}' r='7' fill='none' stroke='{BAD}' stroke-width='2.5'/>")

    x0, x1 = min(xs) - MARGIN, max(xs) + MARGIN
    y0, y1 = min(ys) - MARGIN, max(ys) + MARGIN
    svg = (f"<svg xmlns='http://www.w3.org/2000/svg' width='{x1 - x0}' height='{y1 - y0}' "
           f"viewBox='{x0} {y0} {x1 - x0} {y1 - y0}'><rect x='{x0}' y='{y0}' width='100%' height='100%' fill='#fcfcfb'/>"
           + "".join(body) + "</svg>")
    pathlib.Path(out).write_text(svg, encoding="utf-8")
    print(f"出力: {out} ({x1 - x0} x {y1 - y0})")
    if unconnected:
        print(f"未接続のピン {len(unconnected)} 個: {unconnected}")
    else:
        print("未接続のピンはありません")
    return unconnected


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(2)
    if not pathlib.Path(sys.argv[1]).exists():
        sys.exit(f"エラー: ファイルがありません: {sys.argv[1]}")
    render(sys.argv[1], sys.argv[2])


if __name__ == "__main__":
    main()
